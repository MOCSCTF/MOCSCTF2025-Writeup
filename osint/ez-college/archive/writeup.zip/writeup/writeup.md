題目附件

![college](writeup/college.jpg)

看到這張圖片，很明顯是個圖書館，就像題目名稱一樣，我們需要找到這個大學的名字用`MOCSCTF{}`給包起來就是flag了，直接使用Google視圖

![image-20250416122024693](writeup/image-20250416122024693.png)

直接就查找出來了，是成都大學的圖書館，那麼flag為

```
MOCSCTF{成都大學}
```

