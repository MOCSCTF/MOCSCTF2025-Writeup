MOCSCTF{3ez_r@c-es-you@-good}
