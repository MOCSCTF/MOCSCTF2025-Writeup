<?php

header("Location: https://www.baidu.com", true, 302);

echo "<!-- /s3cret/rce.php -->";
exit;
