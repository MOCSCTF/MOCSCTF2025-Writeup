<?php
return array (
  'CMSVersion' => '9.5.21',
  'CMSReleaseDate' => '2024-12-12',
);