<?php
return array (
  'DB_TYPE' => 'mysqli',
  'DB_HOST' => 'localhost',
  'DB_NAME' => 'youdiancms',
  'DB_USER' => 'root',
  'DB_PWD' => '123456',
  'DB_PORT' => '3306',
  'DB_PREFIX' => 'youdian_',
);
?>