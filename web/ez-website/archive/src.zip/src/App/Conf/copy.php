<?php
 return array (
  'CMSName' => '友点企业网站管理系统',
  'CMSEnName' => 'YouDianCMS',
  'CompanyName' => '友点软件',
  'CompanyEnName' => 'YouDian Software',
  'CompanyFullName' => '长沙友点软件科技有限公司',
  'CompanyAddress' => '长沙市经济开发区板仓路尚都花园城6栋1单元904',
  'CompanyUrl' => 'http://www.youdiancms.com',
  'CompanyUrl1' => 'http://www.youdiancms.com',
  'CompanyTelephone' => '0731-84037726',
  'CompanyFax' => '0731-84037726',
  'CompanyEmail' => '38319835@qq.com',
  'CompanyQQ' => '38319835',
  'CompanyPostCode' => '410100',
);